GDP+Tempo manuscript — Oxford Bulletin of Economics and Statistics submission package v2 (2026-10-16).
submission/: anonymized manuscript.docx, title_page.docx, cover_letter.docx, supplementary_material.docx, figures/, tables/ (separate files).
reproducibility/: public sources, repo commit, verified instructions, 23-metric comparison CSV, uncertainty scripts+outputs.
internal_qc/: gate reports GATE0–GATE6 + FINAL_DECISION.txt.

# Public data sources (all publicly obtainable; no private inputs)
- Penn World Table 10.01 (rgdpna, emp, hc, csh_i, delta): https://www.rug.nl/ggdc/productivity/pwt/
- World Bank Changing Wealth of Nations (NW.PCA.TO produced capital): https://datacatalog.worldbank.org/ / WDI API
- World Bank WDI (R&D intensity, labour inputs): https://data.worldbank.org/
- OECD Gross Fixed Capital Formation by asset type: https://stats.oecd.org/
Frozen extracts + SHA-256 ledger in public repo `source_data/`; acquisition
ledger and checksums recorded in the repository's data-acquisition docs.
